import "./style.css";

const THRESHOLD = 0.9;
// Preferred order for outlets; any other outlet found in the data is added after these.
const OUTLET_ORDER = ["Tampines", "Jurong", "Orchard"];

// Supabase connection, read from environment variables at build time.
// Set VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY in .env (local) or in Vercel's
// Project Settings > Environment Variables. The publishable key is meant for
// browsers; the table only allows reads.
const SUPABASE_URL = (import.meta.env.VITE_SUPABASE_URL || "").replace(/\/+$/, "");
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY || "";
const SUPABASE_TABLE = import.meta.env.VITE_SUPABASE_TABLE || "outlet_weekly";

/*
 * All data loading lives here. Resolves to rows shaped like
 *   { outlet: string, week: "YYYY-MM-DD", sales, target, orders, returns: number }
 * Throws an Error with a readable reason if Supabase can't be read; the page
 * shows that reason instead of falling back to other data.
 */
async function loadData() {
  if (!SUPABASE_URL || !SUPABASE_ANON_KEY) throw new Error("VITE_SUPABASE_URL or VITE_SUPABASE_ANON_KEY is not set. Add them to .env locally, or in Vercel under Project Settings > Environment Variables, then redeploy.");
  const url = `${SUPABASE_URL}/rest/v1/${SUPABASE_TABLE}` +
    `?select=outlet,week,sales,target,orders,returns&order=week.asc`;
  let res;
  try {
    res = await fetch(url, {
      cache: "no-store",
      // New-style sb_publishable_ keys go in apikey only; legacy JWT anon keys also need Authorization.
      headers: SUPABASE_ANON_KEY.startsWith("sb_")
        ? { apikey: SUPABASE_ANON_KEY }
        : { apikey: SUPABASE_ANON_KEY, Authorization: `Bearer ${SUPABASE_ANON_KEY}` }
    });
  } catch (err) {
    throw new Error(`Couldn't reach ${SUPABASE_URL} (${err.message}). Check your internet connection, or whether a firewall or browser extension is blocking supabase.co.`);
  }
  if (!res.ok) {
    let detail = await res.text();
    try { const j = JSON.parse(detail); detail = j.message || j.msg || j.error || detail; } catch (_) {}
    throw new Error(`Supabase returned HTTP ${res.status}: ${detail}`);
  }
  const data = await res.json();
  return data.map(r => ({
    outlet: r.outlet, week: r.week,
    sales: Number(r.sales), target: Number(r.target),
    orders: Number(r.orders), returns: Number(r.returns)
  }));
}

const fmtMoney = n => "$" + Math.round(n).toLocaleString("en-SG");
const fmtInt = n => Math.round(n).toLocaleString("en-SG");
const fmtPct = (n, d = 1) => (n * 100).toFixed(d) + "%";
const fmtWeek = w => new Date(w + "T00:00:00").toLocaleDateString("en-SG", { day: "numeric", month: "short" });

let rows = [];
let current = "All";

function render() {
  const data = current === "All" ? rows : rows.filter(r => r.outlet === current);
  const sum = k => data.reduce((s, r) => s + r[k], 0);
  const sales = sum("sales"), target = sum("target"), orders = sum("orders"), returns = sum("returns");

  if (!data.length) {
    for (const k of ["sales", "target", "orders", "returns"]) {
      document.getElementById(`kpi-${k}`).textContent = "–";
      document.getElementById(`kpi-${k}-note`).textContent = "";
    }
  } else {
  document.getElementById("kpi-sales").textContent = fmtMoney(sales);
  document.getElementById("kpi-sales-note").textContent = `${data.length} outlet-weeks`;
  document.getElementById("kpi-target").textContent = target ? fmtPct(sales / target) : "–";
  document.getElementById("kpi-target-note").textContent = `Target ${fmtMoney(target)}`;
  document.getElementById("kpi-orders").textContent = fmtInt(orders);
  document.getElementById("kpi-orders-note").textContent = orders ? `Avg order ${fmtMoney(sales / orders)}` : "";
  document.getElementById("kpi-returns").textContent = orders ? fmtPct(returns / orders, 2) : "–";
  document.getElementById("kpi-returns-note").textContent = `${fmtInt(returns)} returns`;
  }

  // Bars: scale so the largest value (or 110%) fills the track.
  const ratios = data.map(r => r.sales / r.target);
  const max = Math.max(1.1, ...ratios);
  const pos = v => (v / max * 100) + "%";
  const order = outletsIn(rows);
  const sorted = [...data].sort((a, b) => order.indexOf(a.outlet) - order.indexOf(b.outlet) || a.week.localeCompare(b.week));
  document.getElementById("bars").innerHTML = sorted.map(r => {
    const ratio = r.sales / r.target;
    const low = ratio < THRESHOLD ? " low" : "";
    return `<div class="row" title="${r.outlet} · week of ${r.week}: ${fmtMoney(r.sales)} of ${fmtMoney(r.target)}">
      <div class="name">${r.outlet}<small>Week of ${fmtWeek(r.week)}</small></div>
      <div class="track">
        <div class="fill${low}" style="width:${pos(ratio)}"></div>
        <div class="ref" style="left:${pos(THRESHOLD)}"></div>
        <div class="ref target" style="left:${pos(1)}"></div>
      </div>
      <div class="pct${low}">${fmtPct(ratio)}</div>
    </div>`;
  }).join("") || `<div class="empty">No data.</div>`;

  // Needs attention: worst first.
  const flagged = data
    .map(r => ({ ...r, ratio: r.sales / r.target }))
    .filter(r => r.ratio < THRESHOLD)
    .sort((a, b) => a.ratio - b.ratio);
  document.getElementById("attention").innerHTML = !data.length
    ? `<li class="empty" style="background:none">No data.</li>`
    : flagged.length
    ? flagged.map(r => `<li>
        <div class="who">${r.outlet}<small>Week of ${fmtWeek(r.week)}</small></div>
        <div class="gap">${fmtPct(r.ratio)}<small>${fmtMoney(r.target - r.sales)} short</small></div>
      </li>`).join("")
    : `<li class="empty" style="background:none">Everything is at 90% or above.</li>`;

  document.querySelectorAll("#filter button").forEach(b => b.setAttribute("aria-pressed", String(b.dataset.outlet === current)));
}

function outletsIn(data) {
  const present = [...new Set(data.map(r => r.outlet))];
  const known = OUTLET_ORDER.filter(o => present.includes(o));
  const extra = present.filter(o => !OUTLET_ORDER.includes(o)).sort();
  return [...known, ...extra];
}

function buildFilter() {
  const outlets = outletsIn(rows);
  if (current !== "All" && !outlets.includes(current)) current = "All";
  document.getElementById("filter").innerHTML = ["All", ...outlets]
    .map(o => `<button type="button" data-outlet="${o}">${o}</button>`).join("");
}

function showError(message) {
  const el = document.getElementById("load-error");
  el.hidden = !message;
  document.getElementById("load-error-msg").textContent = message || "";
}

async function refresh() {
  const source = document.getElementById("source-text");
  source.textContent = "Loading from Supabase…";
  try {
    rows = await loadData();
    showError("");
    const time = new Date().toLocaleTimeString("en-SG", { hour: "numeric", minute: "2-digit" });
    source.textContent = `Live from Supabase · ${rows.length} row${rows.length === 1 ? "" : "s"} · loaded ${time}`;
  } catch (err) {
    console.error("Supabase load failed:", err);
    rows = [];
    showError(err.message);
    source.textContent = "Not loaded: Supabase request failed";
  }
  const weeks = [...new Set(rows.map(r => r.week))].sort();
  document.getElementById("period").textContent = weeks.length
    ? `Weekly sales against target · ${fmtWeek(weeks[0])} to ${fmtWeek(weeks[weeks.length - 1])}`
    : "Weekly sales against target";
  buildFilter();
  render();
}

function init() {
  document.getElementById("filter").addEventListener("click", e => {
    const b = e.target.closest("button");
    if (!b) return;
    current = b.dataset.outlet;
    render();
  });
  document.getElementById("reload").addEventListener("click", refresh);
  document.getElementById("retry").addEventListener("click", refresh);
  refresh();
}

init();
